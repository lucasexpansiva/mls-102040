var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-radio-group.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RADIO GROUP MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'No selection',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Nenhuma seleção',
        noOptions: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
let MlRadioGroupMolecule = class MlRadioGroupMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedValue = null;
        this.labelId = `label-${Math.random().toString(36).slice(2, 9)}`;
        this.errorId = `error-${Math.random().toString(36).slice(2, 9)}`;
        this.handleKeyDown = (e) => {
            if (this.disabled || this.readonly || this.loading || !this.isEditing)
                return;
            const selectableItems = this.getSelectableItems();
            if (selectableItems.length === 0)
                return;
            const currentIndex = this.focusedValue
                ? selectableItems.findIndex((item) => item.value === this.focusedValue)
                : this.value
                    ? selectableItems.findIndex((item) => item.value === this.value)
                    : -1;
            switch (e.key) {
                case 'ArrowDown':
                case 'ArrowRight': {
                    e.preventDefault();
                    const nextIndex = currentIndex < selectableItems.length - 1 ? currentIndex + 1 : 0;
                    this.focusedValue = selectableItems[nextIndex].value;
                    break;
                }
                case 'ArrowUp':
                case 'ArrowLeft': {
                    e.preventDefault();
                    const prevIndex = currentIndex > 0 ? currentIndex - 1 : selectableItems.length - 1;
                    this.focusedValue = selectableItems[prevIndex].value;
                    break;
                }
                case 'Enter':
                case ' ': {
                    e.preventDefault();
                    if (this.focusedValue) {
                        const item = this.findItem(this.focusedValue);
                        if (item && !item.disabled) {
                            this.handleSelect(item);
                        }
                    }
                    break;
                }
                case 'Escape': {
                    e.preventDefault();
                    this.focusedValue = null;
                    this.blur();
                    break;
                }
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('keydown', this.handleKeyDown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEventListener('keydown', this.handleKeyDown);
    }
    // ===========================================================================
    // PARSING HELPERS
    // ===========================================================================
    parseItems() {
        const itemElements = this.getSlots('Item');
        return itemElements.map((el) => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML.trim(),
            disabled: el.hasAttribute('disabled'),
        }));
    }
    parseGroups() {
        const groupElements = this.getSlots('Group');
        return groupElements.map((groupEl) => {
            const groupLabel = groupEl.getAttribute('label') || '';
            const itemElements = Array.from(groupEl.querySelectorAll('Item'));
            const items = itemElements.map((el) => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML.trim(),
                disabled: el.hasAttribute('disabled'),
            }));
            return { label: groupLabel, items };
        });
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap((g) => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find((item) => item.value === value);
    }
    getSelectableItems() {
        return this.getAllItems().filter((item) => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.focusedValue = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // CSS HELPERS
    // ===========================================================================
    getContainerClasses() {
        return [
            'flex flex-col gap-2',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getOptionClasses(item) {
        const isSelected = this.value === item.value;
        const isFocused = this.focusedValue === item.value;
        const hasError = this.error !== '';
        return [
            'flex items-center gap-3 px-3 py-2 rounded-lg border transition-all cursor-pointer',
            'bg-white dark:bg-slate-800',
            // Selection state
            isSelected
                ? 'border-sky-500 dark:border-sky-400 bg-sky-50 dark:bg-sky-900/40'
                : 'border-slate-200 dark:border-slate-700',
            // Focus state
            isFocused && !isSelected
                ? 'ring-2 ring-sky-500 dark:ring-sky-400 ring-offset-1'
                : '',
            // Error state (only when not selected)
            hasError && !isSelected
                ? 'border-red-500 dark:border-red-400'
                : '',
            // Hover state
            !item.disabled && !this.disabled && !this.readonly && !this.loading
                ? 'hover:bg-slate-50 dark:hover:bg-slate-700'
                : '',
            // Disabled item
            item.disabled
                ? 'opacity-50 cursor-not-allowed'
                : '',
            // Component disabled/readonly/loading
            this.disabled || this.readonly || this.loading
                ? 'cursor-not-allowed'
                : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getRadioClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all',
            isSelected
                ? 'border-sky-500 dark:border-sky-400 bg-sky-500 dark:bg-sky-400'
                : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800',
            item.disabled
                ? 'opacity-50'
                : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getLabelTextClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'text-sm transition-colors',
            isSelected
                ? 'text-sky-700 dark:text-sky-300 font-medium'
                : 'text-slate-900 dark:text-slate-100',
            item.disabled
                ? 'text-slate-400 dark:text-slate-600'
                : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label
id=${this.labelId}
class="text-sm font-medium text-slate-700 dark:text-slate-300"
>
${unsafeHTML(this.getSlotContent('Label'))}
${this.required
            ? html `<span class="text-red-500 dark:text-red-400 ml-0.5">*</span>`
            : html ``}
</label>
`;
    }
    renderRadioIndicator(item) {
        const isSelected = this.value === item.value;
        return html `
<span class=${this.getRadioClasses(item)}>
${isSelected
            ? html `<span class="w-2 h-2 rounded-full bg-white dark:bg-slate-900"></span>`
            : html ``}
</span>
`;
    }
    renderOption(item) {
        const isSelected = this.value === item.value;
        return html `
<div
role="radio"
aria-checked=${isSelected ? 'true' : 'false'}
aria-disabled=${item.disabled || this.disabled || this.readonly || this.loading
            ? 'true'
            : 'false'}
tabindex=${item.disabled || this.disabled || this.readonly || this.loading
            ? '-1'
            : '0'}
class=${this.getOptionClasses(item)}
@click=${() => this.handleSelect(item)}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
>
${this.renderRadioIndicator(item)}
<span class=${this.getLabelTextClasses(item)}>
${unsafeHTML(item.label)}
</span>
</div>
`;
    }
    renderGroup(group) {
        if (group.items.length === 0)
            return html ``;
        return html `
<div class="flex flex-col gap-1">
<span class="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide px-1">
${group.label}
</span>
<div class="flex flex-col gap-1">
${group.items.map((item) => this.renderOption(item))}
</div>
</div>
`;
    }
    renderRadioOptions() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some((g) => g.items.length > 0);
        if (!hasItems) {
            if (this.hasSlot('Empty')) {
                return html `
<div class="text-sm text-slate-500 dark:text-slate-400 py-2">
${unsafeHTML(this.getSlotContent('Empty'))}
</div>
`;
            }
            return html `
<div class="text-sm text-slate-500 dark:text-slate-400 py-2">
${this.msg.noOptions}
</div>
`;
        }
        return html `
<div
role="radiogroup"
aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
aria-required=${this.required ? 'true' : 'false'}
aria-invalid=${this.error ? 'true' : 'false'}
aria-describedby=${this.error ? this.errorId : ''}
class="flex flex-col gap-2"
>
${standaloneItems.map((item) => this.renderOption(item))}
${groups.map((group) => this.renderGroup(group))}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="flex items-center gap-2 py-2">
<div class="w-4 h-4 border-2 border-sky-500 dark:border-sky-400 border-t-transparent rounded-full animate-spin"></div>
<span class="text-sm text-slate-500 dark:text-slate-400">${this.msg.loading}</span>
</div>
`;
    }
    renderFeedback() {
        if (this.error) {
            return html `
<p
id=${this.errorId}
class="text-xs text-red-600 dark:text-red-400"
>
${unsafeHTML(this.error)}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p class="text-xs text-slate-500 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : this.placeholder || this.msg.placeholder;
        return html `
<div class="flex flex-col gap-1">
${this.renderLabel()}
<span class="text-sm text-slate-900 dark:text-slate-100">
${selectedItem ? unsafeHTML(displayText) : displayText}
</span>
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
<div class=${this.getContainerClasses()}>
${this.renderLabel()}
${this.loading ? this.renderLoading() : this.renderRadioOptions()}
${this.renderFeedback()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlRadioGroupMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlRadioGroupMolecule.prototype, "focusedValue", void 0);
MlRadioGroupMolecule = __decorate([
    customElement('groupselectone--ml-radio-group')
], MlRadioGroupMolecule);
export { MlRadioGroupMolecule };
